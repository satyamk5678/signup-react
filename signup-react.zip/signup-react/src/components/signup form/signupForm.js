import React, { Component } from 'react';
import { Panel, Form, FormGroup, FormControl, Button } from 'react-bootstrap';


const divStyle = {
  display: 'flex',
  alignItems: 'center',
  marginTop: -100
};

const panelStyle = {
  backgroundColor: 'rgba(255,255,255,0.5)',
  border: 0,
  paddingLeft: 20,
  paddingRight: 20,
  width: 300,
};

const buttonStyle = {
  marginBottom: 0
};

class LoginForm extends Component {

  handleFormSubmit(e) {
    e.preventDefault();

    console.log("FORM SUBMIT!");

  }

  render() {

    <div class="wrapper login">
      <div class="container">
        <div class="col-left">
          <div class="login-text">
            <h2>Learn to paint by watching others</h2>
            <p>See how experienced painters create art in real time. watching scripted tutorials is great. but understading how artists think is invaluable.</p>

          </div>
        </div>
      </div>

      <div class="col-right">
        <div class="login-form">
          <h2>Try it free for 7 days then $20/mo there after</h2>
          <form action=""></form>
        </div>
      </div>
    </div>
    return (
      <div style={divStyle}>
        style={panelStyle}>
        <Form></Form> horizontal className="LoginForm" id="loginForm">
        <FormGroup controlId="formEmail">
          <FormControl type="email" placeholder="First Name" />
        </FormGroup>
        <Form> </Form>horizontal className="LoginForm" id="loginForm">
        <FormGroup controlId="formEmail">
          <FormControl type="email" placeholder="Last Name" />
        </FormGroup>
        <Form horizontal className="LoginForm" id="loginForm">
          <FormGroup controlId="formEmail">
            <FormControl type="email" placeholder="Email Address" />
          </FormGroup>
          <FormGroup controlId="formPassword">
            <FormControl type="password" placeholder="Password" />
          </FormGroup>
          <FormGroup style={buttonStyle} controlId="formSubmit">
            <Button bsStyle="primary" type="submit" onClick={this.handleFormSubmit}>
              Claim your free trial
            </Button>
          </FormGroup>
        </Form>

      </div>
    )
  }
}

export default LoginForm;
